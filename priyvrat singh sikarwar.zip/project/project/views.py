from django.shortcuts import render
from products.models import productmodel

def index(request):
    return render(request,'index.html')

def product(request):   
    col=productmodel.objects.all()
    params={'coldata':col}
    return render(request,'product.html',params)

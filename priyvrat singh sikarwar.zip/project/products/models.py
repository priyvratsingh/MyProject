from django.db import models

class productmodel(models.Model):
    name=models.CharField(max_length=50)
    weight=models.CharField(max_length=50)
    price=models.CharField(max_length=20)
    created_at=models.DateTimeField()
    updated_at=models.DateTimeField()

# Create your models here.

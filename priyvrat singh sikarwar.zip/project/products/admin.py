from django.contrib import admin
from.models import productmodel
admin.site.register(productmodel)

# Register your models here.

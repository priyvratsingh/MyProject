
from django.db import models
from django.db.models.deletion import DO_NOTHING

class usermodel(models.Model):
    first_name=models.CharField(max_length=50)
    last_name=models.CharField(max_length=50)
    email=models.EmailField()
    password=models.CharField(max_length=50)
    username=models.CharField(max_length=50)

class postmodel(models.Model):
    usermodel=models.ForeignKey(usermodel,on_delete=DO_NOTHING)
    user=models.CharField(max_length=50)
    Text=models.CharField(max_length=500)
    created_at=models.DateTimeField()
    updated_at=models.DateTimeField()



from django.contrib import admin
from django.db.models.expressions import F
from.models import usermodel
admin.site.register(usermodel)

# Register your models here.
